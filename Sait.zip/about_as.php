<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>О нас</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<menu>
    <table>
        <tr>
            <td>
                <a href="index.php">Главная</a>
            </td>
            <td>
                <a href="portfolio.php">Порфолио</a>
            </td>
            <td>
                <a href="about_as.php">О нас</a>
            </td>
            <td>
                <a href="contact.php">Заявка</a>
            </td>
        </tr>
    </table>
</menu>
<main>
    <img src="Image/дом.jpeg">
    <div class="col" style="width: 20%; height: 320px; border-radius: 5px; background-color: rgba(223, 227, 213, 0.43);">
    <ul>
        <li><p>Телефон: +0(000)-00-00</p></li>
        <li><p>Почта: a@ga.com</p></li>
    </ul>
    </div>
</main>
</body>
</html>